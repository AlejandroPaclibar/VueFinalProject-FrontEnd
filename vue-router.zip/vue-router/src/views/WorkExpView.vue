<template>
    <div class="work_exp">
      <h1>This is an work experience page</h1>
    </div>
  </template>
  
  <style scoped>
  
  .work_exp {
    background-color: rgb(161, 189, 247);
    width: 65%;
    margin-left: 35%;
    margin-top: -736px;
    height: 94vh;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  </style>
  