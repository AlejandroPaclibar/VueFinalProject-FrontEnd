<template>
    <div class="portfolio">
      <h1>This is an portfolio page</h1>
    </div>
  </template>
  
  <style scoped>
  
  .portfolio {
    background-color: rgb(161, 189, 247);
    width: 65%;
    margin-left: 35%;
    margin-top: -736px;
    height: 94vh;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  </style>
  