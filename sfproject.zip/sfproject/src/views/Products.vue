<template>
      <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <div class="card-container">
      <div v-for="product in products" :key="product.id" class="card">
        <h2 class="title">{{ product.title }}</h2>
        <img :src="product.thumbnail" alt="image" class="img">
        <p class="text">Discount:<span class="discount"> -{{ product.discountPercentage }} %</span></p>
        <p class="text">Price: <span class="price ">$ {{ product.price }}</span> </p>
        <div class="card-body">
          <h5 class="card-title">{{ product.title }}</h5>
          <p class="card-text">{{ product.description }}</p>
          
        </div>
        <div class="b"><a href="sda" class="btn">Buy now</a> </div>
      </div>
    </div>
  </template>
<script>
import ProductsData from '../../products.json';

export default{
  data(){
    return{ products: ProductsData}
  }
}
</script>
  
  <style scoped>
  .img{
    height: 40%;
    width: 100%;
  }
  .card-container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
  }
  
  .card {
    position: relative;
    border: 1px solid #ddd; 
    border-radius: 8px;
    overflow: hidden;
    width: 100%;
    max-width: 300px; 
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out;
    background-color: #ffffff6f;
    height: 550px;
    margin-top: 5%;
  }
  
  .card:hover {
    transform: translateY(-7px);
  }
  
  .title {
    font-size: 1.3rem;
    margin-bottom: 10px;
    font-family: 'Quicksand', sans-serif;
    font-weight: 600;
    margin-left: 20px;
  }
  
  .card-img-top {
    width: 100%;
    height: auto;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
  }
  .text {
    margin-left: 15px;
    margin-top: 5px;
  }
  
  .absolute {
    position: absolute;
  }
  
  .discount {
    color: #dc3545; 
  }
  
  .price     {
    color: #28a745; 
  }
  
  .end-0 {
    right: 0;
  }
  
  .end-1 {
    right: 1rem;
  }
  
  .card-body {
    padding: 15px;
  }
  
  .card-title {
    font-size: 1.25rem;
    margin-bottom: 10px;
    font-family: 'Quicksand', sans-serif;
    font-weight: 800;
  }
  
  .card-text {
    color: #555;
    height: 80px;
    font-family: 'Quicksand', sans-serif;
    font-weight: 600;

  }
  
  .btn {
    display: inline-block;
    font-weight: bold;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    user-select: none;
    border: 1px solid transparent;
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    line-height: 1.5;
    border-radius: 0.25rem;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out,
      border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    color: #fff;
    background-color: #007bff;
    margin-top: 20px;
  }
  .b {
    display: flex;
    align-items: center;
    margin-left: 20px;
  
  }
  </style>
  






