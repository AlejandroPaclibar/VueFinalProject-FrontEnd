<template>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <div class="container flex gap-5 justify-content-center">
      <categoryList v-for="category in cat" :key="category.brand" :category="category" />
    </div>
  </template>
  
  <script setup>
  import categoryList from '../components/categoryList.vue';
  
  const cat = [
    {
      "brand": "Laptop",
      "description": "Laptops, categorized under consumer electronics, are portable computing devices extensively utilized for work and entertainment purposes. Available in specialized variations like business or gaming laptops, they address a wide range of user requirements."
    },
    {
      "brand": "Smartphone",
      "description": "Phones are consumer electronics, including smartphones, feature phones, and related accessories. Smartphones, with advanced features like internet connectivity and app support, dominate this category in the modern market."
    }
  ];
  </script>
  
  <style scoped>
  /* Add your custom styles here */
  
  /* Example styles using Tailwind CSS */
  .card {
    max-width: 400px;
    background-color: #ffffff6f;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    
    overflow: hidden;
    transition: transform 0.3s ease-in-out;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  }
  
  .card:hover {
    transform: translateY(-5px);
  }
  
  .card-header {
    background-color: #4a90e2;
    color: #000000;
    padding: 1rem;
    text-align: center;
    font-size: 1.25rem;
  }
  
  .card-body {
    padding: 1rem;
  }
  
  </style>
  