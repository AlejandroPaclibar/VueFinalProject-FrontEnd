<template>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<div class="upper">

    <div class="personal_info">

    <!-- <p> Personal Information</p> -->

    </div>



</div>




<div class="center">

<div class="image">

    <img src="../components/image1.jpg" alt="">

</div>
        
<div class="infos">

    <div class="name">

        <li>  Name:  </li>

        <p>  Alejandro A. Paclibar </p>

    </div>

    <div class="address">

        <li>  Address:    </li>

        <p>   Cabulijan, Tubigon, Bohol   </p>

    </div>

    <div class="sex">

        <li>  Sex: </li>

        <p>  Male </p>

    </div>
    
    <div class="birth">

        <li>  Birth Date:  </li>

        <p>   October 10, 2002 </p>

    </div>

    <div class="height">

        <li>  Height:  </li>
        
        <p>   5'5  </p>

    </div>

    <div class="weight">

        <li>  weight:  </li>
        
        <p>   45 kilograms  </p>

    </div>

</div>    

</div>

</template>



<style scoped>

img {
    width: 30vh;
    border-radius: 50%;
    margin-top: 45px;
    box-shadow: 0px 0px 25px rgb(69, 67, 67);
}

.image {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 9%;
    border-radius: 50%;

}

.center {

    background-color: #ffffff6f;
    height: 85vh;
    margin-top: 1%;
    width: 60%;
    margin-left: 20%;

}
.infos {
    line-height: 50px;
    margin-top: 40px;

}
li, p {
    font-size: 18px;
    letter-spacing: 3px;
    font-family: 'Quicksand', sans-serif;
    font-weight: 500;
}

.name, .name, .address, 
.sex, .height, .weight,
.birth {
    display: flex;
    gap: 20px;
    margin-left: 25%;

}
</style>
