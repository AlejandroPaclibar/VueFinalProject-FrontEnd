<template>

    <div class="con">
      
        <div class="fullname">
            <p>Paclibar, Alejandro A.</p>
        </div>
    </div>
</template>

<style scoped>
.con{
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: rgba(21, 20, 41, 0.914);
    height: 10vh;
}

.fullname {
    margin-right: 45%;
    font-size: 70px;
    width: 100%;


}
P{  
    font-size: 22px;
    color: white;
    font-family: 'Quicksand', sans-serif;
    letter-spacing: 5px;
    margin-left: 20px;
}


</style>